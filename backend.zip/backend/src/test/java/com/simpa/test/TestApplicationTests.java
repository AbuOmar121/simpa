package com.simpa.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")  // Activate test profile
class TestApplicationTests {

    @Test
    void contextLoads() {
        // Test will pass if application context loads
    }
}