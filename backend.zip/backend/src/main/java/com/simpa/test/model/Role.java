package com.simpa.test.model;

public enum Role {
    USER,
    ADMIN
}